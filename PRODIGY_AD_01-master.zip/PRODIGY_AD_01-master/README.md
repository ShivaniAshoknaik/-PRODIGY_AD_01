# Calculator
![WhatsApp Image 2023-07-27 at 8 07 56 AM](https://github.com/nidhirk2020/Calculator/assets/96578258/16e6f9e7-130c-4c11-aa98-09627be12b30)
![cal_ss](https://github.com/nidhirk2020/PRODIGY_AD_01/assets/96578258/a2f87af9-de34-4660-b281-7452696b8aba)
